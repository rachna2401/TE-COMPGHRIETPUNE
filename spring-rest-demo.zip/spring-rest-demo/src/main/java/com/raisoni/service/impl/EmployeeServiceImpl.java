package com.raisoni.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.raisoni.dao.EmployeeDao;
import com.raisoni.model.Employee;
import com.raisoni.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public Employee getEmployee() {
		// TODO Auto-generated method stub
		Employee emp = employeeDao.getEmployee();
		//business logic on emp
		return emp;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployee();
	}

	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDao.addEmployee(emp);
	}
}
